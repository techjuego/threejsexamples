import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import * as THREE from 'three';
// @ts-ignore
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import ViewCubeControls from './view-cube-controls';

@Component({
  selector: 'app-three-viewer',
  imports: [],
  templateUrl: './three-viewer.html',
  styleUrl: './three-viewer.scss',
})
export class ThreeViewer implements AfterViewInit, OnDestroy {
  @ViewChild('rendererContainer', { static: true }) rendererContainer!: ElementRef<HTMLDivElement>;
  @ViewChild('cubeSceneContainer', { static: true }) cubeSceneContainer!: ElementRef<HTMLDivElement>;

  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private orbitControls!: OrbitControls;

  private cubeRenderer!: THREE.WebGLRenderer;
  private cubeScene!: THREE.Scene;
  private cubeCamera!: THREE.PerspectiveCamera;
  private viewCube!: ViewCubeControls;

  private animationId!: number;

  ngAfterViewInit(): void {
    this.initMainScene();
    this.initCubeScene();
    this.animate();
    window.addEventListener('resize', this.onWindowResize.bind(this));
  }

  ngOnDestroy(): void {
    window.removeEventListener('resize', this.onWindowResize.bind(this));
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
    if (this.cubeRenderer) {
      this.cubeRenderer.dispose();
    }
    if (this.orbitControls) {
      this.orbitControls.dispose();
    }
  }

  private initMainScene(): void {
    const container = this.rendererContainer.nativeElement;

    this.scene = new THREE.Scene();

    const aspect = container.clientWidth / container.clientHeight;
    this.camera = new THREE.PerspectiveCamera(75, aspect, 0.1, 1000);
    this.camera.position.set(0, 15, 30);

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(window.devicePixelRatio);
    container.appendChild(this.renderer.domElement);

    this.orbitControls = new OrbitControls(this.camera, this.renderer.domElement);
    this.orbitControls.enableDamping = true;
    this.orbitControls.dampingFactor = 0.05;

    this.scene.add(new THREE.GridHelper(100, 10, 0xffffff, 0xffffff));
    this.scene.add(new THREE.AxesHelper(30));
    
    // Some placeholder geometry so OrbitControls feels satisfying
    const cubeGeo = new THREE.BoxGeometry(10, 10, 10);
    const cubeMat = new THREE.MeshNormalMaterial();
    this.scene.add(new THREE.Mesh(cubeGeo, cubeMat));
  }

  private initCubeScene(): void {
    const container = this.cubeSceneContainer.nativeElement;

    this.cubeRenderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    this.cubeRenderer.setSize(150, 150);
    container.appendChild(this.cubeRenderer.domElement);

    this.cubeScene = new THREE.Scene();
    this.cubeCamera = new THREE.PerspectiveCamera(50, 1, 0.1, 1000);
    this.cubeCamera.position.set(0, 0, 70);
    this.cubeCamera.lookAt(0, 0, 0);

    // Add a static white plane behind the View Cube
    const planeGeo = new THREE.PlaneGeometry(300, 300);
    const planeMat = new THREE.MeshBasicMaterial({ color: 0xffffff, depthWrite: false });
    const bgPlane = new THREE.Mesh(planeGeo, planeMat);
    bgPlane.position.z = -50;
    this.cubeScene.add(bgPlane);

    this.viewCube = new ViewCubeControls(this.cubeCamera, undefined, undefined, this.cubeRenderer.domElement);
    this.cubeScene.add(this.viewCube.getObject());

    (this.viewCube as any).addEventListener('angle-change', (event: any) => {
      let q = event.quaternion.clone();
      if (typeof q.invert === 'function') q.invert();
      else if (typeof (q as any).inverse === 'function') (q as any).inverse();

      // update camera position to orbit around the target
      const distance = this.camera.position.distanceTo(this.orbitControls.target);
      this.camera.position.set(0, 0, distance).applyQuaternion(q).add(this.orbitControls.target);
      this.camera.quaternion.copy(q);
    });
  }

  private animate = () => {
    this.animationId = requestAnimationFrame(this.animate);
    
    const isAnimatingCube = this.viewCube && !!(this.viewCube as any)._animation;

    if (this.orbitControls && !isAnimatingCube) {
      this.orbitControls.update();
    }
    
    // Sync ViewCube to OrbitControls only when ViewCube isn't animating itself
    if (this.viewCube && !isAnimatingCube) {
      let camQ = this.camera.quaternion.clone();
      if (typeof camQ.invert === 'function') camQ.invert();
      else if (typeof (camQ as any).inverse === 'function') (camQ as any).inverse();
      this.viewCube.setQuaternion(camQ);
    }
    
    if (this.viewCube) {
      this.viewCube.update();
    }
    
    if (this.renderer && this.scene && this.camera) {
      this.renderer.render(this.scene, this.camera);
    }
    
    if (this.cubeRenderer && this.cubeScene && this.cubeCamera) {
      this.cubeRenderer.render(this.cubeScene, this.cubeCamera);
    }
  };

  private onWindowResize(): void {
    const container = this.rendererContainer.nativeElement;
    if (this.camera && this.renderer) {
      this.camera.aspect = container.clientWidth / container.clientHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(container.clientWidth, container.clientHeight);
    }
  }
}
